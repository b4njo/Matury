#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cmath>

using namespace std;

void zadanie4_1()
{
    ifstream in;
    in.open("dane/punkty.txt");
    ofstream out;
    out.open("wyniki/wynik1.txt");

    double x, y;

    int cw1=0, cw2=0, cw3=0, cw4=0;
    while(in >> x >> y)
    {
        if(x>0 && y>0)
            cw1++;
        if(x<0 && y>0)
            cw2++;
        if(x<0 && y<0)
            cw3++;
        if(x>0 && y<0)
            cw4++;
    }
    out << cw1 << endl << cw2 << endl << cw3 << endl << cw4 << endl;
}

void zadanie4_2()
{
    ifstream in;
    in.open("dane/okregi.txt");
    ofstream out;
    out.open("wyniki/wynik2.txt");

    int x, y, r;

    vector <pair <int, int> > v;

    /*while(in >> x >> y >> r)
    {
        out << x << " " << y << " " << r << endl;
    }*/

    while(in >> x >> y >> r)
    {
        if(fabs(y)==r)
            v.push_back(make_pair(x, y));
    }
    sort(v.begin(), v.end());
    for(int i=0; i<v.size(); i++)
        out << v[i].first << " " << v[i].second << " " << fabs(v[i].second) << endl;
}

void zadanie4_3()
{
    ifstream in;
    in.open("dane/punkty.txt");
    ofstream out;
    out.open("wyniki/wynik3.txt");

    double x1, y1, x2, y2, tempX, tempY, pole=0, pierwszyX, pierwszyY;

    //vector <pair <int, int> > v;
    in >> x1 >> y1;
    tempX=x1;
    tempY=y1;
    pierwszyX=x1;
    pierwszyY=y1;

    while(in >> x2 >> y2)
    {
        pole+=(fabs(tempX*y2-x2*tempY))/2;
        tempX=x2;
        tempY=y2;
    }
    pole+=(fabs(tempX*pierwszyY-pierwszyX*tempY))/2;
    out << (int)pole << endl;
}
int main()
{
    zadanie4_1();
    zadanie4_2();
    zadanie4_3();
    return 0;
}
